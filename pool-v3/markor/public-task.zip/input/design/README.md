# 设计证据草稿

`north-preview.png` 是实际原版 Markor 的未加工截图，720x1280，API28，emulator-5580，来自 markor-explore-26/after.png。

SHA256：4064b1e7f2d689516d24c68bd39d447ed8dec40f858c55373d2ebe2a0ac307c9

对应 NB-04 的可见范围：一级/二级标题、粗体/斜体、表格、有序列表、任务项，以及 NB-05 的 project index 链接入口。代码区在屏幕下方，本图不能证明代码排版正确。页面不是交互背景素材；实现必须响应用户对任意文本的编辑并重新渲染。

完整文件列表、搜索替换、横屏、深色及字体缩放设计尚缺。题面未与全套设计一一对齐，不可冻结发布。

`south-preview.png` 来自 markor-relative-links-02/step-004/after.png，规格相同；实际查看确认显示 South basin 及 S-017=4、S-018=9 表格，证明同名文件导航后的目标身份。SHA256：5a0a4eaf0d0a09125e8192bf099ca3e52cf326d6f37ce5a5e23e68fe2b23b514。

## 文件管理状态

以下也是 API28、720x1280 原版未加工截图，对应 NB-F01 至 F06。截图为设计参照，不可用作不可交互背景。独立人工审核尚未完成。

| 文件 | 原始采集点 | 状态与边界 |
| --- | --- | --- |
| new-file-dialog.png | markor-management-enter-01/step-002/after.png | 新建对话框、Markdown/.md/空模板；键盘遮住底部按钮，需收起后操作 |
| new-file-confirmation.png | markor-create-review-01/step-003/after.png | 输入 Review 并收起键盘后的确认状态 |
| rename-conflict.png | markor-rename-conflict-01/step-005/after.png | README.md 重名提示，OK 灰显禁用 |
| renamed-document.png | markor-rename-conflict-01/step-009/after.png | Reviewed 文档标题及原始正文，证明改名后打开了正确文件 |
| move-destination.png | markor-move-review-01/step-001/after.png | 目标 north 目录及 SELECT THIS FOLDER 确认按钮，对应 NB-F07 |
| move-conflict.png | markor-move-conflict-open-01/step-006/after.png | observations.md 与 south 的冲突说明及三个处理选项，对应 NB-F09 |

前三张相关输入控件须真实可编辑，冲突提示须依据实际目录状态更新。最终文件是否保存正确由独立文件核验判断，截图不能替代磁盘证据。文件 SHA256 由公开导出的 manifest 逐项记录。
