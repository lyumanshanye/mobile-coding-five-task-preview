# 已观察的清单详情设计

checklist-detail.png来自冻结参考App 6.4.0 FOSS在Android API29、720x1280像素设备上的实际截图。显示重启后打开的Equipment review清单：Inspect north sensor已完成，其余两项未完成；工具栏提供附件、分类、标签、分享和更多操作。原始采集见omni-checklist-restart-menu-01/step-002。

本图只覆盖一个清单详情状态，不是全App完整设计稿。状态栏时钟及Created/Updated相对时间属于动态内容，不作为像素完全一致的要求。应实现可编辑条目和真实完成状态，不允许用该截图作为页面背景或控件替身。长条目布局、键盘、旋转和字体缩放仍需补充设计与验证。

image-viewer.png展示实际打开input/media/sensor-readings.png的内部图片查看器，完整测量表与底部标识均可见，原始证据omni-open-image-01。它是查看器设计参考，不是待显示图片本身；实现必须加载原始媒体文件，不能用该整屏截图替代可交互查看器。
