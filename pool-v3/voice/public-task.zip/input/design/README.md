# 有声书局部参考截图

参考 App 为 Voice 8.9.0，提交 aa413505e8b871255fb40a518d3ad2554cb69f9d，API 28，720 x 1280，density 320。截图为真实设备观察，未重绘。

| 文件 | 状态 | 维护侧来源 |
| --- | --- | --- |
| library-imported.png | 五个 MP3 导入后形成三本书，显示分组与时长 | evidence/voice-explore-16/after.png |
| arrival-paused.png | Field Journal 第一章 Arrival，0:00 / 0:32，Play | evidence/voice-library-check-01/step-002/after.png |
| return-paused.png | 选择第二章 Return 后，0:00 / 0:33，Play | evidence/voice-chapter-selection-01/step-002/after.png |

这些截图覆盖局部静态状态，不是全 App 设计稿。系统时间不作为界面复刻目标。截图不能证明发声、媒体推进、后台控制或睡眠定时；真实音频播放仍未验证。
