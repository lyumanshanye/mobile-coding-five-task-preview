# 首页、日历与编辑表单设计证据草稿

`imported-history-home.png` 是冻结版本 Loop 在 API28、720x1280 模拟器上导入本题历史后采集的原始截图，已实际查看。SHA256为92fa818f0384ddf948f43c681f80072b0c3b8e691d945742f33232f7ed49fe6d。

页面显示4条活动习惯：二值Read、分钟Read、Training、Coffee；Practice初始归档，不在默认列表中。截图可见10月13至16日、分钟/杯单位、数值与打卡/跳过标记及强度环。启用了跳过与缺失数据问号，日界延迟到凌晨3点的选项关闭；周起始日当时显示Sunday。

覆盖HB-01的不同类型及同名列表展示、HB-03的局部状态展示、HB-08的默认活动列表。此图不能证明所有历史日期、强度算法、连续记录或归档恢复正确，也不构成全套设计稿。完整详情、统计、归档筛选、横屏、深色和大字体页面仍缺。

`coffee-calendar-initial.png`为干净导入原始history.json后、修改之前的Coffee日历弹窗，来自API28、720x1280、density320、字体缩放1、en-US、UTC。SHA256为b36e3b5ffbc792599c00ab44ea726f24c995eb2d412ce84145d006865bf97de2。

该状态覆盖HB-02/HB-03/HB-06：周按列排列、星期按行排列，月与年标签帮助跨月定位；日期单元格必须能打开对应日期的数值与备注编辑。实色、灰色及斜纹等状态从记录与目标推导，不可按截图颜色填充固定格子。10月15日的原始记录由history.json提供，用户修改后应刷新日历及其后方历史图。弹窗外的详情背景不是独立第二个可编辑日历；导航与返回应符合弹窗层级。截图中的系统时钟不是业务数据或需复刻的固定值。

这张图补充日历展开态，不覆盖所有状态配色、数值编辑框、零目标、周计划或自适应规范，完整Spec-设计稿映射仍未冻结。

图像仅用于外观参考，不能作为不可交互背景；页面必须根据真实历史数据渲染。同名习惯按稳定身份区分，不能按截图顺序硬编码。

`coffee-edit-initial.png`为目标仍为2杯时的实际编辑表单，SHA256为cc8d1245b510582c7b12a6fc89b05a1c24973b991f8bd1f4d94c1d1730662f3f。对应HB-01/HB-07：名称、提示、单位、数值目标、频率、目标方向和备注属于同一习惯；顶部保存用于提交修改，不能把目标值与历史记录值混淆。图中提醒保持Off，提醒设置与颜色修改的完整行为不因出现在图中就视为已冻结。该次截图设备时区为America/Los_Angeles，其他规格仍为API28、720x1280、density320、字体缩放1、en-US；不构成UTC日界或适配验证。

## 每周计划的交互状态映射

以下五张原始截图均为API28、720x1280、density320、字体缩放1、en-US、America/Los_Angeles，业务日期2026-10-16。Training初态来自history.json；编辑仅把10月15日yes改为skip。系统时钟、导航栏和状态栏不作为固定业务值。

| 图像 | 操作卡 | 可观察状态及交互要求 |
| --- | --- | --- |
| training-detail-initial.png | HB-W01 | Training详情含提示training、每周三次、备注及概览；Total10、Score37%。向下滚动可到达历史日历，不允许用静态折线替代真实历史驱动的图表 |
| training-calendar-initial.png | HB-W05 | 日历弹窗按列显示周、按行显示星期；10月15日实际完成，10月13日跳过；原始no与自动休息按派生规则呈现。可点击每个有效历史日期 |
| training-record-editor.png | HB-W05至W06 | 选中日期后显示原备注；下方依次为完成、跳过、未完成、未知。操作须改变选中日期的实际记录；本链只验证跳过分支 |
| training-calendar-edited.png | HB-W06 | 10月15日变为跳过斜纹，其他日期按重新计算的状态呈现；返回关闭日历，不退出整个App |
| training-detail-edited.png | HB-W07 | 退出到桌面、终止进程并重启后，详情显示Total9、Score34%。其精确强度为0.3389，显示舍入不能倒过来成为计算输入 |

橙色区域表示当前习惯颜色，灰色文本、实色完成块、浅色休息块和斜纹跳过块应随状态渲染；备注标记归属对应日期。图表中的Week聚合选项在图中可见，但其完整聚合与切换契约仍待补齐。本组只补齐每周历史编辑子链，不覆盖全部HB-01至HB-10。

图像SHA256：

| 文件 | SHA256 |
| --- | --- |
| training-detail-initial.png | ae0e800b097b5d959d10fe025c8510bff80023b4d43005c641578fc97112c7f4 |
| training-calendar-initial.png | 92bd78cd20ae44717aa3b6da217edaad3c613a51688c3a5f01a1076bfc8112b6 |
| training-record-editor.png | 654584cbc7a90ebcfd31154b38d6b09c6431bd228582ec2768e07547da751154 |
| training-calendar-edited.png | 47e124839c287d566dc00af3dfb99ca263de522d13d9174563e6c3eb2228e4ba |
| training-detail-edited.png | 332b54e586245866e3c7d463df59192e67d83dcb38dd6293075049892a507410 |
